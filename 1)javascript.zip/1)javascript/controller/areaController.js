const express = require('express');
module.exports = class areaControl {
    async calculate_area(request,response){
        const dim1 = request.body.dim1;
        const dim2 = request.body.dim2;
        const area = dim1*dim2;
        const resposta = { Dimensão1 : dim1, Dimensão2 : dim2, Área : area};
        response.status(200).send(resposta);
    }
}