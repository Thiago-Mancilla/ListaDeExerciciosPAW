const express = require('express');
module.exports = class ageControl {
    async calculate_age(request,response){
        const age = request.body.Idade;
        const days = age * 365;
        const hours = days*24;
        const minutes = hours*60;
        const seconds = minutes*60;
    
        const resposta = { Idade: age, Dias : days , Horas : hours, Minutos : minutes, Segundos : seconds };
        response.status(200).send(resposta);
    }
}