const express = require('express');
module.exports = class triangleControl {
    async classify_triangle(request,response){
        const l1 = request.body.l1;
        const l2 = request.body.l2;
        const l3 = request.body.l3;
        let classificacao = "";

        if(l1 == l2 & l2 == l3){ 
            classificacao = "Equilatero"  
        }else if(l1 == l2 || l2 == l3 || l1 == l3){
            classificacao = "Isoceles"
        }else if(l1 != l2 && l1 != l3 && l2 != l3){
            classificacao = "Escaleno"
        }
        const resposta = { Classificação : classificacao };
        response.status(200).send(resposta);
    }
}