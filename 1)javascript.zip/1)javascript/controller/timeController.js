const express = require('express');
module.exports = class timeControl {
    async convert_hours(request,response){
        const horas = request.body.horas;
        const minutes = horas * 60;
    
        const resposta = { minutos : minutes};
        response.status(200).send(resposta);
    }
}