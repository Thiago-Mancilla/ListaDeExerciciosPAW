const express = require('express');
module.exports = class aprovationControl {
    async verify_aprovation (request,response){
        const n1 = request.body.n1;
        const n2 = request.body.n2;
        const n3 = request.body.n3;
        const media = (n1+n2+n3)/3;
        const aprovacao = media >= 7 ? 'Aprovado' : "Reprovado";
        const resposta = { Media : media, Aprovação : aprovacao};
        response.status(200).send(resposta);
    }
}