const express = require('express');
module.exports = class salaryControl {
    async calculate_salary(request,response){
        let nome = request.body.Nome;
        let horas_trabalhadas = request.body.QtdHoras;
        let valor_hora = request.body.ValorHora;
        let qtd_filhos = request.body.QtdFilhos;

        let salario = horas_trabalhadas*valor_hora;

        let acrescimo = salario;
        let resposta = {};

        let i = 2;
        if (qtd_filhos > 3) {
            for(i = 2; i<=qtd_filhos ; i++){
                acrescimo += acrescimo*0.03;
            }
            resposta = { Nome : nome, Salario : salario, Acrescimo : acrescimo};
        }else{
            resposta = {Nome : nome, Salario : salario};
        }
        response.status(200).send(resposta);

    }
}