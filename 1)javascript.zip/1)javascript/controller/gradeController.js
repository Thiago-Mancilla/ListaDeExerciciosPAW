const express = require('express');
module.exports = class gradeControl {
    async calculate_media(request,response){
        const grade1 = request.body.Nota1;
        const grade2 = request.body.Nota2;
        const average = (grade1+grade2)/2;
        const resposta = { Nota1 : grade1, Nota2 : grade2, Media : average};
        response.status(200).send(resposta);
    }
}