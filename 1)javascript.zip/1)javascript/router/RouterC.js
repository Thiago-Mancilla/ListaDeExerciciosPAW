const express = require('express');
const gradeControl = require('../controller/gradeController');
const MiddlewareC = require('../middleware/MiddlewareC')

module.exports = class RouterC {
    constructor(){
        this._router = express.Router();
        this._gradeControl = new gradeControl();
        this._middlewareC = new MiddlewareC();
    }

    createRoutes(){
        this._router.post('/',
            this._middlewareC.validar_notas,
            this._gradeControl.calculate_media
        );
        return this._router;
    }
}