const express = require('express');
const ageControl = require('../controller/ageController');
const MiddlewareB = require('../middleware/MiddlewareB')

module.exports = class RouterB {
    constructor(){
        this._router = express.Router();
        this._ageControl = new ageControl();
        this._middlewareB = new MiddlewareB();
    }

    createRoutes(){
        this._router.post('/',
            this._middlewareB.validar_idade,
            this._ageControl.calculate_age
        );
        return this._router;
    }
}