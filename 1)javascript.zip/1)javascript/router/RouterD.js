const express = require('express');
const areaControl = require('../controller/areaController');
const MiddlewareD = require('../middleware/MiddlewareD')

module.exports = class RouterD {
    constructor(){
        this._router = express.Router();
        this._areaControl = new areaControl();
        this._middlewareD = new MiddlewareD();
    }

    createRoutes(){
        this._router.post('/',
            this._middlewareD.validar_dimensoes,
            this._areaControl.calculate_area
        );
        return this._router;
    }
}