const express = require('express');
const salaryControl = require('../controller/salaryController');
const MiddlewareF = require('../middleware/MiddlewareF');

module.exports = class RouterF {
    constructor(){
        this._router = express.Router();
        this._salaryControl = new salaryControl();
        this._middlewareF = new MiddlewareF();
    }

    createRoutes(){
        this._router.post('/',
            this._middlewareF.validar_dados,
            this._salaryControl.calculate_salary
        );
        return this._router;
    }
}