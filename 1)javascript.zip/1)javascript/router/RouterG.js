const express = require('express');
const triangleControl = require('../controller/triangleController');
const MiddlewareG = require('../middleware/MiddlewareG')

module.exports = class RouterG {
    constructor(){
        this._router = express.Router();
        this._triangleControl = new triangleControl();
        this._middlewareG = new MiddlewareG();
    }

    createRoutes(){
        this._router.post('/',
            this._middlewareG.validar_lados ,
            this._triangleControl.classify_triangle
        );
        return this._router;
    }
}