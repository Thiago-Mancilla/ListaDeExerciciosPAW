const express = require('express');
const aprovationControl = require('../controller/aprovationController');
const MiddlewareE = require('../middleware/MiddlewareE')

module.exports = class RouterE {
    constructor(){
        this._router = express.Router();
        this._aprovationControl = new aprovationControl();
        this._middlewareE = new MiddlewareE();
    }

    createRoutes(){
        this._router.post('/',
            this._middlewareE.validar_notas,
            this._aprovationControl.verify_aprovation
        );
        return this._router;
    }
}