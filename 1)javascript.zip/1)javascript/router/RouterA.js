const express = require('express');
const timeControl = require('../controller/timeController');
const MiddlewareA = require('../middleware/MiddlewareA');

module.exports = class RouterA {
    constructor(){
        this._router = express.Router();
        this._timeControl = new timeControl();
        this._middlewareA = new MiddlewareA();
    }

    createRoutes(){
        this._router.post('/',
            this._middlewareA.validar_hora,
            this._timeControl.convert_hours
        );
        return this._router;
    }
}