const express = require('express');

module.exports = class MiddlewareF {
    validar_dados(request,response,next){
        let nome = request.body.Nome;
        let horas_trabalhadas = request.body.QtdHoras;
        let valor_hora = request.body.ValorHora;
        let qtd_filhos = request.body.QtdFilhos;
        
        if(isNaN(horas_trabalhadas) || isNaN(valor_hora) || isNaN(qtd_filhos)){
            const objResposta = {
                status : false,
                msg : "Insira valores válidos para os campos numéricos!"
            }
            response.status(200).send(objResposta)
        }else if(nome == ""){
            const objResposta = {
                status : false,
                msg : "Insira nome válido!"
            }
            response.status(200).send(objResposta)
        }else if(horas_trabalhadas <= 0 || valor_hora <= 0 || qtd_filhos < 0){
            const objResposta = {
                status : false,
                msg : "Insira numéricos válidos!"
            }
            response.status(200).send(objResposta)
        }else{
            next()
        }
    }
}