const express = require('express');

module.exports = class MiddlewareD {
    validar_dimensoes(request,response,next){
        const dim1 = request.body.dim1;
        const dim2 = request.body.dim2;
        if(isNaN(dim1) || isNaN(dim2)){
            const objResposta = {
                status : false,
                msg : "As dimensões devem ser números!"
            }
            response.status(200).send(objResposta)
        }else if(dim1 <= 0 || dim2 <= 0){
            const objResposta = {
                status : false,
                msg : "As dimensões devem ser valores numéricos positivos diferentes de zero!"
            }
            response.status(200).send(objResposta)
        }
        else{
            next()
        }
    }
}