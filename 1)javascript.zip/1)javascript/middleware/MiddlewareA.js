const express = require('express');

module.exports = class MiddlewareA {
    validar_hora(request,response,next){
        const horas = request.body.horas
        if(isNaN(horas) || horas <= 0){
            const objResposta = {
                status : false,
                msg : "Horas deve ser um número e maior que zero!"
            }
            response.status(200).send(objResposta)
        }else{
            next()
        }
    }
}