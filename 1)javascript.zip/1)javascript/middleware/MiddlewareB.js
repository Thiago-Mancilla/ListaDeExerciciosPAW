const express = require('express');

module.exports = class MiddlewareB {
    validar_idade(request,response,next){
        const idade = request.body.Idade
        if(isNaN(idade) || idade <= 0){
            const objResposta = {
                status : false,
                msg : "Idade deve ser um número e maior que zero!"
            }
            response.status(200).send(objResposta)
        }else{
            next()
        }
    }
}