const express = require('express');

module.exports = class MiddlewareG {
    validar_lados(request,response,next){
        const l1 = request.body.l1;
        const l2 = request.body.l2;
        const l3 = request.body.l3;

        if(isNaN(l1) || isNaN(l2) || isNaN(l3)){
            const objResposta = {
                status : false,
                msg : "Os lados devem ser valores numéricos!"
            }
            response.status(200).send(objResposta)
        }else if(l1 <= 0 || l2 <= 0 || l3 <= 0){
            const objResposta = {
                status : false,
                msg : "Os lados devem ser valores numéricos positivos e maiores que zero!"
            }
            response.status(200).send(objResposta)
        }else{
            next()
        }
    }
}