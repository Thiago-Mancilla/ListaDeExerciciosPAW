const express = require('express');

module.exports = class MiddlewareE {
    validar_notas(request,response,next){
        const n1 = request.body.n1;
        const n2 = request.body.n2;
        const n3 = request.body.n3;

        if(isNaN(n1) || isNaN(n2) || isNaN(n3)){
            const objResposta = {
                status : false,
                msg : "As notas devem ser números!"
            }
            response.status(200).send(objResposta)
        }else if(n1 < 0 || n1 > 10 || n2 < 0 || n2 > 10 || n3 < 0 || n3 > 10){
            const objResposta = {
                status : false,
                msg : "As notas devem ser de 0 a 10!"
            }
            response.status(200).send(objResposta)
        }else{
            next()
        }
    }
}