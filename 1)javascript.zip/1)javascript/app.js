const express = require('express'); //importa o express

const RouterA = require('./router/RouterA'); const routerA = new RouterA();
const RouterB = require('./router/RouterB'); const routerB = new RouterB();
const RouterC = require('./router/RouterC'); const routerC = new RouterC();
const RouterD = require('./router/RouterD'); const routerD = new RouterD();
const RouterE = require('./router/RouterE'); const routerE = new RouterE();
const RouterF = require('./router/RouterF'); const routerF = new RouterF();
const RouterG = require('./router/RouterG'); const routerG = new RouterG();

const app = express(); //recupera uma instancia de express
const portaServico = 2007;
app.use(express.json());


// a) Converte horas para minutos
app.use('/convert-hours', 
    routerA.createRoutes()
);


// b) Informar dias horas minutos e segundos vividos por Idade informada
app.use('/calculate-age',
    routerB.createRoutes()
);


// c) Calcular a média a partir de duas notas informadas
app.use('/calculate-grade',
    routerC.createRoutes()
)


// d) Calcular área do terreno a partir das dimensões
app.use('/calculate-area',
    routerD.createRoutes()
)


// e) Calcular média e aprovação a partir de três notas
app.use('/calculate-aprovation',
    routerE.createRoutes()
)


// f) Salário e bonificação
app.use('/calculate-salary',
    routerF.createRoutes()
)


// g) Classificar triângulo de acordo com lados
app.use('/classify-triangles',
    routerG.createRoutes()
)

//inicia a espera por requisições http na porta 3000
app.listen(portaServico);
console.log(`Api rodando no endereço: http:localhost:${portaServico}/`)