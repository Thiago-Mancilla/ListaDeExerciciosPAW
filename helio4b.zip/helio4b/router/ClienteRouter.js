
const express = require('express');
const ClienteMiddleware = require('../middleware/ClienteMiddleware');
const ClienteControl = require('../controle/ClienteControl');
const JwtMiddleware = require('../middleware/JWTMiddleware');

module.exports = class ClienteRouter {
    constructor() {
        this._router = express.Router();
        this._clienteMiddleware = new ClienteMiddleware();
        this._clienteControl = new ClienteControl();
        this._jwtMiddleware = new JwtMiddleware();
    }
    createRoutes() {
        this._router.get('/',
            this._jwtMiddleware.validate,
            this._clienteControl.readAll
        );

        this._router.get('/:idcliente',
            this._jwtMiddleware.validate,
            this._clienteControl.readById
        );

        this.router.post('/',
            this._jwtMiddleware.validate,
            this._clienteMiddleware.validate_nomecliente,
            this._clienteMiddleware.validate_emailcliente,
            this._clienteMiddleware.validate_senhacliente,
            this._clienteMiddleware.isNotEmailCadastrado,
            this._clienteControl.create
        );

        this.router.delete('/:idcliente',
            this._jwtMiddleware.validate,
            this._clienteControl.delete
        );

        this.router.put('/:idcliente',
            this._jwtMiddleware.validate,
            this._clienteMiddleware.validate_nomecliente,
            this._clienteMiddleware.validate_emailcliente,
            this._clienteMiddleware.validate_senhacliente,
            this._clienteControl.update
        );

        return this._router;
    }

    get router() {
        return this._router;
    }

    set router(newRouter) {
        this._router = newRouter;
    }
    // Getter e Setter para _clienteMiddleware
    get clienteMiddleware() {
        return this._clienteMiddleware;
    }

    set clienteMiddleware(newclienteMiddleware) {
        this._clienteMiddleware = newclienteMiddleware;
    }

    // Getter e Setter para _clienteControl
    get clienteControl() {
        return this._clienteControl;
    }

    set clienteControl(newclienteControl) {
        this._clienteControl = newclienteControl;
    }

    // Getter e Setter para _JWTMiddleware
    get jwtMiddleware() {
        return this._jwtMiddleware;
    }

    set jwtMiddleware(newJWTMiddleware) {
        this._jwtMiddleware = newJWTMiddleware;
    }
}
