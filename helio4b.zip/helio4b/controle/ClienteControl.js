const express = require('express');
const Cliente = require('../modelo/Cliente');

module.exports = class ClienteControl {
    async login(request, response) {

        const cliente = new Cliente();

        cliente.email = request.body.cliente.email
        cliente.senha = request.body.cliente.senha

        const logou = cliente.login();
        if (logou == true) {
            const objResposta = {
                cod: 1,
                status: logou,
                msg: 'logado com sucesso'
            };
            response.status(200).send(objResposta);
        } else {
            const objResposta = {
                cod: 2,
                status: isCreated,
                msg: "erro ao efetuar login"
            };
            response.status(401).send(objResposta);
        }
    }

    async readAll(request, response) {
        const cliente = new Cliente();
        const dadosclientes = await cliente.readAll();
        const objResposta = {
            cod: 1,
            status: true,
            clientes: dadosclientes
        }
        response.status(200).send(objResposta);

    }

    async readById(request, response) {
        const cliente = new Cliente();
        const idcliente = request.params.idcliente

        const dadosclientes = await cliente.readByID(idcliente);
        const objResposta = {
            cod: 1,
            status: true,
            clientes: dadosclientes
        }
        response.status(200).send(objResposta);
    }

    async create(request, response) {
        const cliente = new Cliente();

        cliente.nome = request.body.cliente.nomecliente;
        cliente.email = request.body.cliente.email;
        cliente.senha = request.body.cliente.senha;
        cliente.nascimento = request.body.cliente.nascimento;

        const cadastrou = await cliente.create();
        if (cadastrou == true) {
            const objResposta = {
                cod: 1,
                status: true,
                clientes: [{
                    "cliente": {
                        //"idcliente": cliente.idcliente,
                        "nomecliente": cliente.nome,
                        "email": cliente.email,
                        "senha": cliente.senha,
                        "nascimento": cliente.nascimento,
                    }
                }]
            }
            response.status(201).send(objResposta);
        } else {
            const objResposta = {
                cod: 1,
                status: false,
                msg: "Falha ao cadastrar cliente",
                clientes: [{
                    "cliente": {
                        //"idcliente": cliente.idcliente,
                        "nomecliente": cliente.nome,
                        "email": cliente.email,
                        "senha": cliente.senha,
                        "nascimento": cliente.nascimento,
                    }
                }]
            }
            response.status(200).send(objResposta);
        }
    }

    async update(request, response) {

        const cliente = new Cliente();

        cliente.idCliente = request.params.idcliente
        cliente.nome = request.body.cliente.nomecliente;
        cliente.email = request.body.cliente.email;
        cliente.senha = request.body.cliente.senha;
        cliente.nascimento = request.body.cliente.nascimento;

        const atualizou = await cliente.update(cliente.idCliente);
        if (atualizou == true) {
            const objResposta = {
                cod: 1,
                status: true,
                clientes: [{
                    "cliente": {
                        //"idcliente": cliente.idcliente,
                        "nomecliente": cliente.nome,
                        "email": cliente.email,
                        "senha": cliente.senha,
                        "nascimento": cliente.nascimento,
                    }
                }]
            }
            response.status(200).send(objResposta);
        } else {
            const objResposta = {
                cod: 1,
                status: false,
                msg: "Falha ao atualizar cliente",
                clientes: [{
                    "cliente": {
                        //"idcliente": cliente.idcliente,
                        "nomecliente": cliente.nome,
                        "email": cliente.email,
                        "senha": cliente.senha,
                        "nascimento": cliente.nascimento,
                    }
                }]
            }
            response.status(200).send(objResposta);
        }
    }


    async delete(request, response) {

        const cliente = new Cliente();
        cliente.idCliente = request.params.idcliente


        const excluiu = await cliente.delete();
        if (excluiu == true) {
            const objResposta = {
                cod: 1,
                status: true,
                msg: "Excluido com sucesso",
                clientes: [{
                    "cliente": {
                        //"idcliente": cliente.idcliente,
                        "nomecliente": cliente.nomecliente,
                        "email": cliente.email,
                        "senha": cliente.senha,
                        "nascimento": cliente.nascimento,
                    }
                }]
            }
            response.status(200).send(objResposta);
        } else {
            const objResposta = {
                cod: 1,
                status: false,
                msg: "Falha ao excluir cliente",
                clientes: [{
                    "cliente": {
                        "idcliente": cliente.idcliente,
                        "nomecliente": cliente.nomecliente,
                        "email": cliente.email,
                        "senha": cliente.senha,
                        "nascimento": cliente.nascimento,
                    }
                }]
            }
            response.status(200).send(objResposta);
        }
    }
};
