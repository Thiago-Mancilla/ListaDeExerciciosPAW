const express = require('express');
const path = require('path');  // Módulo para manipular caminhos de arquivo
const ClienteRouter = require('./router/ClienteRouter');
const LoginRouter = require('./router/LoginRouter');

const app = express();

const portaServico = 8080;

app.use(express.json());

const clienteRouter = new ClienteRouter();
const loginRouter = new LoginRouter();


app.use('/login',
    loginRouter.createRoutes()
);

app.use('/clientes',
    clienteRouter.createRoutes()
);

// Inicia o servidor, escutando na porta definida, e exibe uma mensagem no console com a URL onde o servidor está rodando.
app.listen(portaServico, () => {
    console.log(`API rodando no endereço: http://localhost:${portaServico}/`);
});

