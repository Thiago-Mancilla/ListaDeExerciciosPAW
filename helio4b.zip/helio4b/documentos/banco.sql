create database api;
use api;

create table Cliente(
	idCliente int primary key auto_increment,
    nome varchar(64),
    email varchar(64),
    senha varchar(64),
    nascimento varchar(64));

insert  into Cliente (nome, senha) values ("admin", md5("admin"));


