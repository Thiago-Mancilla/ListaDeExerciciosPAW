// Importa o módulo Banco para realizar conexões com o banco de dados.
const Banco = require('./Banco');

// Define a classe Cliente para representar a entidade Cliente.
class Cliente {
    // Construtor da classe Cliente que inicializa as propriedades.
    constructor() {
        this._idCliente = null;  
        this._nome = null;  
        this._email = null;  
        this._senha = null;  
        this._nascimento = null; 
    }

    // Método assíncrono para criar um novo funcionário no banco de dados.
    async create() {
        const conexao = Banco.getConexao();  // Obtém a conexão com o banco de dados.
        const SQL = 'INSERT INTO Cliente (nome, email, senha, nascimento) VALUES (?, ?, ?, ?);';

        try {
            const [result] = await conexao.promise().execute(SQL, [this._nome, this._email, this._senha, this._nascimento]);
            this._idCliente = result.insertId;  // Armazena o ID gerado pelo banco de dados.
            return result.affectedRows > 0;  // Retorna true se a inserção foi bem-sucedida.
        } catch (error) {
            console.error('Erro ao criar o cliente:', error);
            return false;
        }
    }

    // Método assíncrono para excluir um funcionário do banco de dados.
    async delete() {
        const conexao = Banco.getConexao();
        const SQL = 'DELETE FROM Cliente WHERE idCliente = ?;';

        try {
            const [result] = await conexao.promise().execute(SQL, [this._idCliente]);
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao excluir o cliente:', error);
            return false;
        }
    }

    // Método assíncrono para atualizar os dados de um funcionário no banco de dados.
    async update() {
        const conexao = Banco.getConexao();
        const SQL = 'UPDATE Cliente SET nome = ?, email = ?, senha = ?, nascimento = ? WHERE idCliente = ?;';
        console.log([this._nome, this._email, this._senha, this._nascimento, this._idCliente]);
        try {
            const [result] = await conexao.promise().execute(SQL, [this._nome, this._email, this._senha, this._nascimento, this._idCliente]);
            return result.affectedRows > 0;
        } catch (error) {
            console.error('Erro ao atualizar o cliente:', error);
            return false;
        }
    }

    // Método assíncrono para ler todos os funcionários do banco de dados.
    async readAll() {
        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM Cliente ORDER BY nome;';

        try {
            const [rows] = await conexao.promise().execute(SQL);
            return rows;
        } catch (error) {
            console.error('Erro ao ler clientes:', error);
            return [];
        }
    }

    // Método assíncrono para ler um funcionário pelo seu ID.
    async readByID(idCliente) {
        this._idCliente = idCliente;

        const conexao = Banco.getConexao();
        const SQL = 'SELECT * FROM Cliente WHERE idCliente = ?;';
        try {
            const [rows] = await conexao.promise().execute(SQL, [this._idCliente]);
            return rows;
        } catch (error) {
            console.error('Erro ao ler o cliente pelo ID:', error);
            return null;
        }
    }

    async isClienteByEmail(email) {
        const conexao = Banco.getConexao();  // Obtém a conexão com o banco de dados.

        const SQL = 'SELECT COUNT(*) AS qtd FROM Cliente WHERE email = ?;';  
        try {
            const [rows] = await conexao.promise().execute(SQL, [email]);  // Executa a query.
            return rows[0].qtd > 0;  // Retorna true se houver algum email no banco
        } catch (error) {
            console.error('Erro ao verificar o email:', error);  // Exibe erro no console se houver falha.
            return false;  // Retorna false caso ocorra um erro.
        }
    }
    async login() {
        const conexao = Banco.getConexao(); // Obtém a conexão com o banco de dados.
        const SQL = `
            SELECT COUNT(*) AS qtd, idCliente, nome, email
            FROM Cliente WHERE email = ? AND senha = MD5(?);`; 
        // Query SQL para selecionar o funcionário com base no email e senha.

        try {
            // Prepara e executa a consulta SQL com parâmetros.
            const [rows] = await conexao.promise().execute(SQL, [this._email, this._senha]);

            if (rows.length > 0 && rows[0].qtd === 1) {
                const tupla = rows[0];
                // Configura os atributos do funcionário.
                this._idCliente = tupla.idCliente;
                this._nome = tupla.nome;
                this._email = tupla.email;
                return true; // Login bem-sucedido.
            }

            return false; // Login falhou.
        } catch (error) {
            console.error('Erro ao realizar o login:', error); // Exibe erro no console se houver falha.
            return false; // Retorna false caso ocorra um erro.
        }
    }

    // Getters e setters para as propriedades da classe.

    get idCliente() {
        return this._idCliente;
    }

    set idCliente(idCliente) {
        this._idCliente = idCliente;

    }

    get nome() {
        return this._nome;
    }

    set nome(nome) {
        this._nome = nome;

    }

    get email() {
        return this._email;
    }

    set email(email) {
        this._email = email;

    }

    get senha() {
        return this._senha;
    }

    set senha(senha) {
        this._senha = senha;

    }

    get nascimento() {
        return this._nascimento;
    }

    set nascimento(nascimento) {
        this._nascimento = nascimento;
    }

}

// Exporta a classe Cliente para que possa ser utilizada em outros módulos.
module.exports = Cliente;
